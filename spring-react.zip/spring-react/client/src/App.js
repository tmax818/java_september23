import {useState} from 'react'
import Dashboard from './components/Dashboard';
import DonationForm from './components/StudentForm';
import Main from './views/Main';

function App() {
  
  

  return (
    <div>
      <Main />
    </div>
  );
}

export default App;
